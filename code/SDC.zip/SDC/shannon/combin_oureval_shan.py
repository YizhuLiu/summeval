import sys
import re
import os

import json

combdict = dict() 
with open('infodiff_our') as r, open('oureval_dist') as o, open('combin_infodiff_ourdist','w') as w:
	for liner, lineo in zip(r.readlines(), o.readlines()):
		liner = json.loads(liner)
		lineo = json.loads(lineo)
		combdict['doc_id'] = liner['doc_id']
		combdict['system'] = liner['system']
		infodiff = liner['info_diff']
		dist = lineo['Pearson'][0]
		combdict['infodiff'] = infodiff
		combdict['-Pearson'] = (0-dist)*pow(10,8)
		#combs = 2*infodiff*pow(10,-11)*dist*pow(10,10)/(infodiff*pow(10,-11)+dist*pow(10,10))
		#combs = 0.8*infodiff+0.1*(dist-0.99999999999)*pow(10,8)
		#combs = 2*infodiff*(dist-0.99999999999)*pow(10,8)/(infodiff+(dist-0.99999999999)*pow(10,8))
		combs = 2*infodiff*(1-dist)*pow(10,8)/(infodiff+(1-dist)*pow(10,8))
		#combs = (1-dist)*pow(10,8)
		combdict['combscore'] = combs
		w.write(json.dumps(combdict)+'\n')
