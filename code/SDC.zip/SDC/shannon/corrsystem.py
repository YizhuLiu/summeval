import sys
import re
import os

from collections import defaultdict

import scipy
import scipy.stats
import numpy as np
import json

import math


path = sys.argv[1]
autoscores = {}
with open(path) as r:
	autoscores = json.load(r)

humanscores = {}
with open('systemhumanscores.json') as r:
	humanscores = json.load(r)

aspects = ["coherence", "consistency", "fluency", "relevance"]
#syss = ['M0', 'M1', 'M2', 'M5', 'M8', 'M9', 'M10', 'M11', 'M12', 'M13', 'M14', 'M15', 'M17', 'M20', 'M22', 'M23']
corrdic = defaultdict(dict)
metric = sys.argv[2]

for a in aspects:
	oauto = []
	auto = []
	manual = []
	#for key in syss:
	for key in autoscores.keys():
		oauto.append(autoscores[key][sys.argv[2]])
		manual.append(humanscores[key][a])
	for o in oauto:
		auto.append(o)
	pr = scipy.stats.pearsonr(auto, manual)[0]
	sr = scipy.stats.spearmanr(auto, manual)[0]
	kr = scipy.stats.kendalltau(auto, manual)[0]
	corrdic[metric][a] = []
	corrdic[metric][a].append(pr)
	corrdic[metric][a].append(sr)
	corrdic[metric][a].append(kr)
print('finish....')

with open('corr_'+path,'w') as w:
	scores = json.dumps(corrdic,indent=4)
	w.write(scores)
