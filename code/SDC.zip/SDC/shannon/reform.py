import sys
import re
import os

import json

path = 'infodiff_our'
with open(path) as r, open(path+'_score','w') as w:
	for line in r.readlines():
		line = json.loads(line)
		line['score'] = line['info_diff']
		w.write(json.dumps(line)+'\n')

path = 'infodiff_our_len'
with open(path) as r, open(path+'_score','w') as w:
	for line in r.readlines():
		line = json.loads(line)
		line['score'] = line['infodiffF']
		w.write(json.dumps(line)+'\n')
