import sys
import re
import os

import json

import collections

systemdic = collections.defaultdict(dict)
with open(sys.argv[1]) as r:
	lines = r.readlines()
	for line in lines:
		line = json.loads(line)
		key = 'Pearson'
		if  key not in systemdic[line['system']]:
					systemdic[line['system']][key] = 0
		systemdic[line['system']][key] += line[key][0]
		if 'count' not in systemdic[line['system']]:
				systemdic[line['system']]['count'] =0
		systemdic[line['system']]['count'] += 1
	print(systemdic)	
scoredic=collections.defaultdict(dict)
for key in systemdic:
	for a in systemdic[key]:
		if 'count' not in a:
			scoredic[key][a] = systemdic[key][a]/systemdic[key]['count']
print(scoredic)
with open('systemautoscores_our.json','w') as w:
	json.dump(scoredic, w, indent=4)
