python system_auto.py reimpl/infodiff_our info_diff
python corrsystem.py systemautoscores_info_diff.json info_diff

python system_auto.py reimpl/sdc_star PearsonF
python corrsystem.py systemautoscores_PearsonF.json PearsonF
