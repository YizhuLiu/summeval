import sys
import re
import os

import json

req = sys.argv[1]
with open('corrhuman') as r:
	dicts = json.load(r)
	for key in dicts:
		print(key)
		for m in dicts[key]:
			print(m, dicts[key][m][req])
