CUDA_VISIBLE_DEVICES=3 python -u oureval_len.py --input_file model_annotations.aligned.paired.jsonl \
	--save reimpl/sdc_star
