# Shannon Game
This is the code for the Shannon Score and Information Difference metrics of summary quality as defined in [Play the Shannon Game With Language Models: A Human-Free Approach to Summary Evaluation](https://arxiv.org/abs/2103.10918) to appear at AAAI 2022. This codebase is currently a messy research prototype, but we will clean it up soon.
