echo 'Pearson'
python system_level_correlations.py --correlator_str=pearson
echo 'Spearman'
python system_level_correlations.py --correlator_str=spearman
echo 'Kendall'
python system_level_correlations.py --correlator_str=kendall
