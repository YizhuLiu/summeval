import sys
import re
import os

from collections import defaultdict

import scipy
import scipy.stats
import numpy as np
import json

import math

#evals = ['infodiff_our','infodiff_our_len','infodiff_our_len2','oureval_dist','oureval_dist_len','combin_infodiff_ourdist']
#evals = ['infodiff_our','infodiff_our_len2','oureval_dist','oureval_dist_len','combin_infodiff_ourdist']
evals = ['oureval_dist']

evaldict = defaultdict(list)
for e in evals:
	#with open('reimpl/'+e) as r:
	with open(e) as r:
		#for line in r.readlines()[:500]:
		for line in r.readlines():
			line = json.loads(line)
			if e == 'infodiff_our':
				evaldict[e].append(line['info_diff'])
			if e == 'infodiff_our_len':
				evaldict[e].append(line['info_diff'])
			if e == 'infodiff_our_len2':
				evaldict[e].append(line['infodiffF'])
			if e == 'oureval_dist':
				evaldict[e+'_P'].append(0-line['Pearson'][0])
				evaldict[e+'_S'].append(0-line['Spearman'][0])
				evaldict[e+'_K'].append(0-line['Kendall'][0])
				cr = 1-float(line['num_summ_tokens']/line['num_doc_tokens'])
				p = 0-line['Pearson'][0]
				s = 0-line['Spearman'][0]
				k = 0-line['Kendall'][0]
				evaldict[e+'_PF'].append((p+1)/2*(1+cr)/((p+1)/2+(1+cr)/2))
				evaldict[e+'_SF'].append((s+1)/2*(1+cr)/((s+1)/2+(1+cr)/2))
				evaldict[e+'_KF'].append((k+1)/2*(1+cr)/((k+1)/2+(1+cr)/2))
			#if e == 'oureval_dist_len':
				#evaldict[e+'_P'].append(line['PearsonF'])
				#evaldict[e+'_S'].append(line['SpearmanF'])
				#evaldict[e+'_K'].append(line['KendallF'])
			if e == 'combin_infodiff_ourdist':
				evaldict[e].append(line['combscore'])
		#print(evaldict)
		#exit()
#print(evaldict.keys())
print('finish to load eval scores....')

human = 'model_annotations.aligned.paired.jsonl'

aspects = ["coherence", "consistency", "fluency", "relevance"]
humandict = dict()
for a in aspects:
	humandict[a] = defaultdict(dict)
	with open(human) as r:
		#for line in r.readlines()[:500]:
		for line in r.readlines():
			line = json.loads(line)
			exps = line['expert_annotations']
			for i,s in enumerate(exps):
				if 'e'+str(i) not in humandict[a].keys():
					humandict[a]['e'+str(i)] = []
				humandict[a]['e'+str(i)].append(s[a])
			turs = line['turker_annotations']
			for i,s in enumerate(turs):
				if 't'+str(i) not in humandict[a].keys():
					humandict[a]['t'+str(i)] = []
				humandict[a]['t'+str(i)].append(s[a])
		#print(humandict)
		#print(len(humandict[a]['e0']))
		#exit()

#calculate correlation
corrdict = dict()
for a in aspects:
	corrdict[a] = defaultdict(list)
	#print(evaldict.keys())
	for key in evaldict:
		corrdict[a][key] = defaultdict(dict)

		init = np.zeros(len(evaldict[key]))
		c = 0
		inite = np.zeros(len(evaldict[key]))
		ce = 0
		initt = np.zeros(len(evaldict[key]))
		ct = 0
		
		oauto = evaldict[key]
		auto = []
		for score in oauto:
			auto.append(score)	
		#oauto = evaldict[key]
		#auto = []
		#for score in oauto:
		#	auto.append(0-score)	

		corrdict[a][key] = defaultdict(list)
		for k in humandict[a]:
			#print(k)
			manual = humandict[a][k]
			#print(auto,manual)
			'''
			pr = scipy.stats.pearsonr(auto, manual)[0]
			sr = scipy.stats.spearmanr(auto, manual)[0]
			kr = scipy.stats.kendalltau(auto, manual)[0]
			corrdict[a][key][k].append(pr)
			corrdict[a][key][k].append(sr)
			corrdict[a][key][k].append(kr)
			'''
			init = init+np.array(manual)
			c+=1
			if 'e' in k:
				inite = inite+np.array(manual)
				ce+=1
			if 't' in k:
				initt = inite+np.array(manual)
				ct+=1

		avg = [float(i)/c for i in init]
		avge = [float(i)/ce for i in inite]
		avgt = [float(i)/ct for i in initt]
		
		pexp = scipy.stats.pearsonr(auto, avge)[0]
		sexp = scipy.stats.spearmanr(auto, avge)[0]
		kexp = scipy.stats.kendalltau(auto, avge)[0]
		corrdict[a][key]['alle'].append(pexp)
		corrdict[a][key]['alle'].append(sexp)
		corrdict[a][key]['alle'].append(kexp)
		
		'''
		ptur = scipy.stats.pearsonr(auto, avgt)[0]
		stur = scipy.stats.spearmanr(auto, avgt)[0]
		ktur = scipy.stats.kendalltau(auto, avgt)[0]
		corrdict[a][key]['allt'].append(ptur)
		corrdict[a][key]['allt'].append(stur)
		corrdict[a][key]['allt'].append(ktur)

		pall = scipy.stats.pearsonr(auto, avg)[0]
		sall = scipy.stats.spearmanr(auto, avg)[0]
		kall = scipy.stats.kendalltau(auto, avg)[0]
		corrdict[a][key]['all'].append(pall)
		corrdict[a][key]['all'].append(sall)
		corrdict[a][key]['all'].append(kall)
		'''

print('finish....')

with open('corrhuman','w') as w:
	scores = json.dumps(corrdict,indent=4)
	w.write(scores)
