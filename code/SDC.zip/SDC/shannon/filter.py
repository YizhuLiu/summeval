import sys
import re
import os

import json

from collections import defaultdict

aspects = ['coh','con','flu','rel']
ps = []
ss = []
ks = []
dic = defaultdict(dict)
i = 0
with open('baselines_corr_cnndm') as r:
	lines = r.readlines()
	#print(lines)
	for line in lines:
		if int(i/8) >= 0 and i%8>0:
			line = line.strip().split(' & ')
			#print(line)
			for a in range(len(line[1:])):
				if a+1 not in dic[line[0]].keys():
					dic[line[0]][a+1] = []	
				dic[line[0]][a+1].append(line[a+1])
		i+=1
	#print(dic)
with open('baseline_corr_cnndm_modified','w') as w:
	json.dump(dic,w,indent=4)

