import sys
import re
import json

with open('model_annotations.aligned.paired.jsonl') as r, open('debug.jsonl','w') as w:
     count = 0 
     for line in r.readlines():
         count+=1
         if count>=90 and count<=100:
            w.write(line)
            
