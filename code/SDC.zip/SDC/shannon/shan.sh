CUDA_VISIBLE_DEVICES=1 python -u shannon_impl.py --input_file model_annotations.aligned.paired.jsonl \
	--save reimpl/infodiff_our
