import sys
import re
import os

import json

import collections

systemdic = collections.defaultdict(dict)
with open(sys.argv[1]) as r:
	lines = r.readlines()
	for line in lines:
		line = json.loads(line)
		for scores in line['expert_annotations']:
			for key in scores:
				if  key not in systemdic[line['model_id']]:
					systemdic[line['model_id']][key] = 0
				systemdic[line['model_id']][key] += scores[key]
			if 'count' not in systemdic[line['model_id']]:
				systemdic[line['model_id']]['count'] =0
			systemdic[line['model_id']]['count'] += 1
		'''
		for scores in line['turker_annotations']:
			for key in scores:
				if  key not in systemdic[line['model_id']]:
					systemdic[line['model_id']][key] = 0
				systemdic[line['model_id']][key] += scores[key]
			if 'count' not in systemdic[line['model_id']]:
				systemdic[line['model_id']]['count'] =0
			systemdic[line['model_id']]['count'] += 1
		'''
	#print(systemdic)	
scoredic=collections.defaultdict(dict)
for key in systemdic:
	for a in systemdic[key]:
		if 'count' not in a:
			scoredic[key][a] = systemdic[key][a]/systemdic[key]['count']
print(scoredic)
with open('systemhumanscores.json','w') as w:
	json.dump(scoredic, w, indent=4)
