python combin_oureval_shan.py
python corrhuman.py
python read.py all
