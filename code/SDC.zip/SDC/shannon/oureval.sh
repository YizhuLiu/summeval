CUDA_VISIBLE_DEVICES=0 python -u oureval.py --input_file model_annotations.aligned.paired.jsonl \
	--save reimpl/sdc
#python -u oureval.py --input_file debug.jsonl \
#	--save debug
